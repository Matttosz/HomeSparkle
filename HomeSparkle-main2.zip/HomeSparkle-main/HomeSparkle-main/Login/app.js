// Simulação de uma função para obter dados do usuário
async function getUserData() {
    try {
        // Simulando uma chamada a uma API com dados fictícios
        const response = await new Promise((resolve) => {
            setTimeout(() => {
                resolve({
                    username: "Ana Oliveira",
                    email: "ana.oliveira@exemplo.com",
                    age: 28,
                    address: "Rua das Flores, 123, São Paulo, SP",
                    profilePicture: "https://randomuser.me/api/portraits/women/1.jpg" // Link para a foto de perfil
                });
            }, 1500); // Simula um atraso de 1,5 segundos
        });

        return response;
    } catch (error) {
        console.error('Erro ao obter os dados do usuário:', error);
        throw error;
    }
}

// Função para atualizar a interface com os dados do usuário
function updateUserInfo(userData) {
    document.getElementById('username').textContent = userData.username;
    document.getElementById('email').textContent = userData.email;
    document.getElementById('age').textContent = userData.age;
    document.getElementById('address').textContent = userData.address;
    
    const profileImg = document.getElementById('profile-img');
    profileImg.src = userData.profilePicture;
    profileImg.alt = `Foto de perfil de ${userData.username}`;
}

// Função para lidar com o logout (simulado)
function handleLogout() {
    alert('Você foi desconectado.');
    // Redirecionar ou realizar outras ações necessárias para o logout
}

// Quando a página carrega, obtenha e exiba os dados do usuário
document.addEventListener('DOMContentLoaded', () => {
    getUserData()
        .then(userData => {
            updateUserInfo(userData);
        })
        .catch(error => {
            document.querySelector('.user-info').innerHTML = '<p>Falha ao carregar dados do usuário.</p>';
        });

    // Configurar o botão de logout
    document.getElementById('logout-button').addEventListener('click', handleLogout);
});
